const db = require('../db');

/**
 * Order model
 * Tables expected: orders (id, user_id, address, status, total, created_at)
 * and order_items (id, order_id, product_id, product_name, quantity, price)
 */

const Order = {
    createOrder(userId, address, items, total, deliveryType, deliveryFee, paymentMethod, callback) {
        // Use the shared connection for a transaction
        db.beginTransaction(function(err) {
            if (err) return callback(err);
            const insertOrder = 'INSERT INTO orders (user_id, address, status, total, delivery_type, delivery_fee, payment_method, pickup_collected, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())';
            // pickup_collected defaults to 0 on create
            db.query(insertOrder, [userId, address, 'pending', total, deliveryType || 'doorstep', deliveryFee || 0.00, paymentMethod || null, 0], function(err, result) {
                if (err) return db.rollback(function(){ callback(err); });
                const orderId = result.insertId;
                // Insert items one-by-one to avoid driver-specific bulk-insert issues
                const insertItemSingle = 'INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?, ?, ?, ?, ?)';
                const insertNext = (idx) => {
                    if (idx >= items.length) {
                        // all items inserted, commit
                        return db.commit(function(err) {
                            if (err) return db.rollback(function(){ callback(err); });
                            callback(null, { orderId });
                        });
                    }
                    const it = items[idx];
                    db.query(insertItemSingle, [orderId, it.id, it.productName || it.product_name || '', it.quantity, it.price], function(err) {
                        if (err) {
                            console.error('Failed to insert order item:', err);
                            return db.rollback(function(){ callback(err); });
                        }
                        insertNext(idx + 1);
                    });
                };
                insertNext(0);
            });
        });
    },

    // List all orders with items
    getAllOrders(callback) {
        // Join users to include the customer's email for admin views
        const sql = `SELECT o.id as orderId, o.user_id, u.email as user_email, o.address, o.status, o.total, o.delivery_type, o.delivery_fee, o.payment_method, o.pickup_collected, o.created_at,
            oi.id as itemId, oi.product_id, oi.product_name, oi.quantity, oi.price
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            ORDER BY o.created_at DESC`;
        db.query(sql, function(err, results) {
            if (err) {
                console.error('Order.getAllOrders SQL error:', err);
                // Return empty list instead of error so admin page can render
                return callback(null, []);
            }
            // group by order
            const orders = {};
            results.forEach(row => {
                if (!orders[row.orderId]) orders[row.orderId] = { id: row.orderId, user_id: row.user_id, user_email: row.user_email, address: row.address, status: row.status, total: row.total, delivery_type: row.delivery_type, delivery_fee: row.delivery_fee, payment_method: row.payment_method, pickup_collected: row.pickup_collected, created_at: row.created_at, items: [] };
                if (row.itemId) orders[row.orderId].items.push({ id: row.itemId, product_id: row.product_id, product_name: row.product_name, quantity: row.quantity, price: row.price });
            });
            callback(null, Object.values(orders));
        });
    },

    // Get orders for a specific user with items
    getOrdersByUser(userId, callback) {
        const sql = `SELECT o.id as orderId, o.user_id, u.email as user_email, o.address, o.status, o.total, o.delivery_type, o.delivery_fee, o.payment_method, o.pickup_collected, o.created_at,
            oi.id as itemId, oi.product_id, oi.product_name, oi.quantity, oi.price
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.user_id = ?
            ORDER BY o.created_at DESC`;
        db.query(sql, [userId], function(err, results) {
            if (err) return callback(err);
            const orders = {};
            results.forEach(row => {
                if (!orders[row.orderId]) orders[row.orderId] = { id: row.orderId, user_id: row.user_id, user_email: row.user_email, address: row.address, status: row.status, total: row.total, delivery_type: row.delivery_type, delivery_fee: row.delivery_fee, payment_method: row.payment_method, pickup_collected: row.pickup_collected, created_at: row.created_at, items: [] };
                if (row.itemId) orders[row.orderId].items.push({ id: row.itemId, product_id: row.product_id, product_name: row.product_name, quantity: row.quantity, price: row.price });
            });
            callback(null, Object.values(orders));
        });
    },

    // Get a single order (with items) by order id
    getOrderById(orderId, callback) {
        const sql = `SELECT o.id as orderId, o.user_id, u.email as user_email, o.address, o.status, o.total, o.delivery_type, o.delivery_fee, o.payment_method, o.pickup_collected, o.created_at,
            oi.id as itemId, oi.product_id, oi.product_name, oi.quantity, oi.price
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.id = ?`;
        db.query(sql, [orderId], function(err, results) {
            if (err) return callback(err);
            if (!results || results.length === 0) return callback(null, null);
            const order = { id: results[0].orderId, user_id: results[0].user_id, user_email: results[0].user_email, address: results[0].address, status: results[0].status, total: results[0].total, delivery_type: results[0].delivery_type, delivery_fee: results[0].delivery_fee, payment_method: results[0].payment_method, pickup_collected: results[0].pickup_collected, created_at: results[0].created_at, items: [] };
            results.forEach(row => {
                if (row.itemId) order.items.push({ id: row.itemId, product_id: row.product_id, product_name: row.product_name, quantity: row.quantity, price: row.price });
            });
            callback(null, order);
        });
    },

    // Update delivery status for an order
    updateStatus(orderId, status, callback) {
        const sql = 'UPDATE orders SET status = ? WHERE id = ?';
        db.query(sql, [status, orderId], function(err, result) {
            if (err) return callback(err);
            callback(null, { affectedRows: result.affectedRows });
        });
    }

    ,updatePickupCollected(orderId, collected, callback) {
        const sql = 'UPDATE orders SET pickup_collected = ? WHERE id = ?';
        db.query(sql, [collected ? 1 : 0, orderId], function(err, result) {
            if (err) return callback(err);
            callback(null, { affectedRows: result.affectedRows });
        });
    }

    // Delete an order and its items within a transaction
    ,deleteOrder(orderId, callback) {
        db.beginTransaction(function(err) {
            if (err) return callback(err);
            const delItems = 'DELETE FROM order_items WHERE order_id = ?';
            db.query(delItems, [orderId], function(err) {
                if (err) return db.rollback(function(){ callback(err); });
                const delOrder = 'DELETE FROM orders WHERE id = ?';
                db.query(delOrder, [orderId], function(err, result) {
                    if (err) return db.rollback(function(){ callback(err); });
                    db.commit(function(err) {
                        if (err) return db.rollback(function(){ callback(err); });
                        callback(null, { affectedRows: result.affectedRows });
                    });
                });
            });
        });
    }
};

module.exports = Order;
