const Product = require('../models/Student');

/**
 * ProductController for SupermarketAppMVC
 * Methods accept (req, res), call the Product model, and handle rendering
 * or redirects. Views expected: inventory, product, addProduct, updateProduct
 */

const ProductController = {
	// List all products and render the inventory view
	list(req, res) {
		Product.getAllProducts(function (err, products) {
			if (err) {
				console.error('Error fetching products:', err);
				return res.status(500).send('Error retrieving products');
			}
			// pass a minimal user object as views expect it; in real app use session
			res.render('inventory', { products, user: { username: 'admin', role: 'admin' } });
		});
	},

	// Get a product by ID and render the product view
	getById(req, res) {
		const id = req.params.id;
		Product.getProductById(id, function (err, product) {
			if (err) {
				console.error('Error fetching product by ID:', err);
				return res.status(500).send('Error retrieving product');
			}
			if (!product) return res.status(404).send('Product not found');
			res.render('product', { product, user: null });
		});
	},

	// Render update form for a product
	editForm(req, res) {
		const id = req.params.id;
		Product.getProductById(id, function (err, product) {
			if (err) {
				console.error('Error fetching product for edit:', err);
				return res.status(500).send('Error retrieving product');
			}
			if (!product) return res.status(404).send('Product not found');
			res.render('updateProduct', { product });
		});
	},

	// Add a new product (expects multipart/form-data with optional file upload middleware)
	add(req, res) {
		const { name, quantity, price } = req.body;
		const image = req.file ? req.file.filename : null;
		const product = { name, quantity: Number(quantity || 0), price: Number(price || 0), image };
		Product.addProduct(product, function (err, info) {
			if (err) {
				console.error('Error adding product:', err);
				return res.status(500).send('Error adding product');
			}
			res.redirect('/inventory');
		});
	},

	// Update an existing product by ID
	update(req, res) {
		const id = req.params.id;
		const { name, quantity, price } = req.body;
		let image = req.body.currentImage || null;
		if (req.file) image = req.file.filename;
		const product = { name, quantity: Number(quantity || 0), price: Number(price || 0), image };
		Product.updateProduct(id, product, function (err, info) {
			if (err) {
				console.error('Error updating product:', err);
				return res.status(500).send('Error updating product');
			}
			res.redirect('/inventory');
		});
	},

	// Delete a product by ID
	delete(req, res) {
		const id = req.params.id;
		Product.deleteProduct(id, function (err, info) {
			if (err) {
				console.error('Error deleting product:', err);
				return res.status(500).send('Error deleting product');
			}
			res.redirect('/inventory');
		});
	}
};

module.exports = ProductController;
