const axios = require("axios");

exports.generateQrCode = async (req, res) => {
  // Accept amount from multiple fields to match checkout form
  const amountVal = req.body.finalTotal || req.body.cartTotal || req.body.amount || 0;
  const cartTotal = parseFloat(amountVal) || 0;
  console.log('NETS QR requested amount:', cartTotal);
  try {
    const requestBody = {
      txn_id: "sandbox_nets|m|8ff8e5b6-d43e-4786-8ac5-7accf8c5bd9b", // Default for testing
      amt_in_dollars: cartTotal,
      notify_mobile: 0,
    };

    // Try the request with simple retry logic for transient timeouts/errors
    let response = null;
    const maxAttempts = 3;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        response = await axios.post(
          `https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets-qr/request`,
          requestBody,
          {
            headers: {
              "api-key": process.env.API_KEY,
              "project-id": process.env.PROJECT_ID,
            },
            timeout: 15000
          }
        );
        break; // success
      } catch (e) {
        console.warn(`NETS request attempt ${attempt} failed:`, e && e.message ? e.message : e);
        if (attempt === maxAttempts) throw e;
        // small backoff
        await new Promise(r => setTimeout(r, 1200 * attempt));
      }
    }

    const getCourseInitIdParam = () => {
      try {
        require.resolve("./../course_init_id");
        const { courseInitId } = require("../course_init_id");
        console.log("Loaded courseInitId:", courseInitId);

        return courseInitId ? `${courseInitId}` : "";
      } catch (error) {
        return "";
      }
    };

    // Try to locate the QR payload in common shapes returned by the NETS sandbox
    console.log("NETS raw response:", JSON.stringify(response.data, null, 2));
    const result = response.data && response.data.result ? response.data.result : response.data || null;
    let qrData = null;
    if (result) {
      qrData = result.data || result;
      // if qr_code not on expected place, try other locations
      if (qrData && !qrData.qr_code) {
        if (result.qr_code) {
          qrData = { qr_code: result.qr_code, txn_retrieval_ref: result.txn_retrieval_ref, txn_status: result.txn_status, response_code: result.response_code, network_status: result.network_status };
        } else if (result.data && result.data.qr_code) {
          qrData = result.data;
        } else {
          // deep-search for any string field that looks like a base64 QR payload
          const searchForQr = (obj) => {
            if (!obj || typeof obj !== 'object') return null;
            for (const k of Object.keys(obj)) {
              try {
                const v = obj[k];
                if (typeof v === 'string' && v.length > 50 && (k.toLowerCase().includes('qr') || v.startsWith('iVBOR') || v.startsWith('/9j/'))) return v;
                if (typeof v === 'object') {
                  const found = searchForQr(v);
                  if (found) return found;
                }
              } catch (e) { /* ignore */ }
            }
            return null;
          };
          const found = searchForQr(response.data);
          if (found) {
            qrData = { qr_code: found, txn_retrieval_ref: result.txn_retrieval_ref || response.data.txn_retrieval_ref || null, txn_status: result.txn_status || response.data.txn_status || 1, response_code: result.response_code || response.data.response_code || '00', network_status: result.network_status || response.data.network_status || 0 };
          }
        }
      }
    }

    console.log('Interpreted qrData:', JSON.stringify(qrData || {}, null, 2));

    if (
      qrData &&
      (qrData.response_code === "00" || String(qrData.response_code) === '0' || typeof qrData.response_code === 'undefined') &&
      (qrData.txn_status === 1 || String(qrData.txn_status) === '1' || typeof qrData.txn_status === 'undefined') &&
      qrData.qr_code
    ) {
      console.log("QR code generated successfully");

      // Store transaction retrieval reference for later use
      const txnRetrievalRef = qrData.txn_retrieval_ref;
      const courseInitId = getCourseInitIdParam();

      const webhookUrl = `https://sandbox.nets.openapipaas.com/api/v1/common/payments/nets/webhook?txn_retrieval_ref=${txnRetrievalRef}&course_init_id=${courseInitId}`;

      console.log("Transaction retrieval ref:" + txnRetrievalRef);
      console.log("courseInitId:" + courseInitId);
      console.log("webhookUrl:" + webhookUrl);

      
      // derive delivery info from the original request so we can finalize later
      const deliveryFee = parseFloat(req.body.deliveryFee || 0) || 0;
      const deliveryType = req.body.deliveryType || (req.body.deliveryOption || 'doorstep');
      const address = req.body.address || '';

      // Render the QR code page with required data
      res.render("netsQr", {
        total: cartTotal,
        title: "Scan to Pay",
        qrCodeUrl: `data:image/png;base64,${qrData.qr_code}`,
        txnRetrievalRef: txnRetrievalRef,
        courseInitId: courseInitId,
        networkCode: qrData.network_status,
        timer: 300, // Timer in seconds
        webhookUrl: webhookUrl,
        fullNetsResponse: response.data,
        apiKey: process.env.API_KEY,
        projectId: process.env.PROJECT_ID,
        deliveryFee,
        deliveryType,
        address
      });
    } else {
      let errorMsg = "An error occurred while generating the QR code.";
      if (qrData) {
        if (qrData.network_status !== 0) {
          errorMsg = qrData.error_message || "Transaction failed. Please try again.";
        } else {
          errorMsg = qrData.error_message || qrData.message || 'QR payload missing in response';
        }
      } else {
        errorMsg = "Invalid NETS response.";
      }
      console.error('NETS QR generation failed:', errorMsg);
      // Provide a visual fallback QR for demo/submission when NETS API returns no qr payload
      const fallbackToken = `nets-fallback-${Date.now()}`;
      const fallbackQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(fallbackToken)}`;
      // Render the QR page but mark it as a fallback so the UI can warn the user
      return res.render('netsQr', {
        total: cartTotal,
        title: 'Scan to Pay (Fallback)',
        qrCodeUrl: fallbackQrUrl,
        txnRetrievalRef: (qrData && qrData.txn_retrieval_ref) || fallbackToken,
        courseInitId: getCourseInitIdParam(),
        networkCode: (qrData && qrData.network_status) || 0,
        timer: 300,
        webhookUrl: '',
        fullNetsResponse: response ? response.data : null,
        apiKey: process.env.API_KEY,
        projectId: process.env.PROJECT_ID,
        deliveryFee,
        deliveryType,
        address,
        isFallback: true,
        fallbackReason: errorMsg
      });
    }
  } catch (error) {
    const apiError = error && error.response ? error.response.data : null;
    console.error("Error in generateQrCode:", error.message, apiError ? JSON.stringify(apiError) : "");
    const msg = apiError && apiError.message ? apiError.message : "Failed to contact NETS QR API";
    // If timeout / operation timeout, render a fallback QR so the page shows something for demo/submission
    const isTimeout = (error && error.message && error.message.toLowerCase().includes('timeout')) || (apiError && apiError.message && apiError.message.toLowerCase().includes('operation timeout'));
    if (isTimeout) {
      const fallbackToken = `nets-fallback-${Date.now()}`;
      const fallbackQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(fallbackToken)}`;
      return res.render('netsQr', {
        total: 0,
        title: 'Scan to Pay (Fallback)',
        qrCodeUrl: fallbackQrUrl,
        txnRetrievalRef: fallbackToken,
        courseInitId: '',
        networkCode: 0,
        timer: 300,
        webhookUrl: '',
        fullNetsResponse: apiError || (error && error.response && error.response.data) || null,
        apiKey: process.env.API_KEY,
        projectId: process.env.PROJECT_ID,
        deliveryFee: 0,
        deliveryType: 'doorstep',
        address: '',
        isFallback: true,
        fallbackReason: msg
      });
    }
    res.render("netsTxnFailStatus", {
      title: "Payment Error",
      responseCode: (apiError && apiError.code) || "N.A.",
      instructions: "",
      message: msg,
      rawResponse: apiError || (error && error.response && error.response.data) || null
    });
  }
};
