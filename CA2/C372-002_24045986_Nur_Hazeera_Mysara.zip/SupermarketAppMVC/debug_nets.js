require('dotenv').config();
const nets = require('./services/nets');

// Fake req/res
const req = {
  body: {
    finalTotal: 10.00,
    deliveryFee: 0,
    deliveryType: 'self-pickup',
    address: ''
  },
  session: { user: { id: 1, email: 'debug@example.com' } }
};

const res = {
  render: (view, locals) => {
    console.log('=== RENDER CALL ===');
    console.log('view:', view);
    console.log('locals keys:', Object.keys(locals));
    if (locals.fullNetsResponse) {
      console.log('fullNetsResponse:', JSON.stringify(locals.fullNetsResponse, null, 2).slice(0,2000));
    }
    if (locals.qrCodeUrl) {
      console.log('qrCodeUrl length:', locals.qrCodeUrl ? locals.qrCodeUrl.length : 0);
    }
    // exit after render
    process.exit(0);
  },
  status: (code) => ({ json: (obj) => { console.log('STATUS', code, obj); process.exit(0); } })
};

(async () => {
  try {
    await nets.generateQrCode(req, res);
  } catch (e) {
    console.error('Debug call failed:', e && e.toString());
    process.exit(1);
  }
})();
